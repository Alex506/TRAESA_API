import express from "express"
import cors from "cors"
import morgan from "morgan"
import dotenv from "./src/config/dotenv"
// import db from "./src/config/mssql"
import sql from "mssql"

const app = express()

// middlewares
app.use(morgan('dev'))
app.use(express.json())
app.use(cors())

// // routes
// // req = request -> 
// // res = response
app.get('/', async (req, res) => {
    const sqlConfig = {
        user: process.env.USER,
        password: process.env.PASSWORD,
        server: process.env.SERVER,
        database: process.env.DB,
        options: {
            trustServerCertificate: true
        }
    }
    try {
        await sql.connect(sqlConfig)
        const result = await sql.query("select * from traesa.empleados where identificacion = '1173410685'")
        console.log(result)
    } catch (err) {
        res.json({ "error": err })
    }
    res.json({ "status": "success" })
})

// server
app.listen(5000, () => {
    console.log("http://localhost:5000")
})
