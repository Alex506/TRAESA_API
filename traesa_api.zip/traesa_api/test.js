const sql = require('mssql')

    (() => {
        sql.connect().then(pool => {
            return pool.query('SELECT 1')
        }).then(result => {
            // do something with result
        }).then(() => {
            return sql.close()
        })
    })()