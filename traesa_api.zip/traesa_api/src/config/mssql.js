import sql from "mssql"
import dotenv from "../config/dotenv"

const config = {
    user: process.env.USER,
    password: process.env.PASSWORD,
    server: process.env.SERVER,
    database: process.env.DB,
}

const pool = new sql.ConnectionPool(config)

export { pool }